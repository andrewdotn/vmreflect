TCP Proxy Reflector is a kind of swissknife set of library and programs to access 
internal network resources from outside the LAN !


This package include a library and a fully functional client and server application.
The client running inside the LAN connect to the server running on the Internet
and send him a list of internal Internet resources that the server will make available
through this unique connection. It is then possible to access internal resource from the Internet.
The library and the programs manage authentication and some securities.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3 of the License, or
(at your option) any later version.

The SRP authentication system is free but as its own requirements,
read the SRP documentation.

for more information and download  :

http://blog.magiksys.net/tcp-proxy-reflector


